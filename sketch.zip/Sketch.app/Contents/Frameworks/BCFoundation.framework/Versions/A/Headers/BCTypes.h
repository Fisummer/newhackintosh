//  Created by Alan Francis on 15/01/2015.
//  Copyright (c) 2017 Bohemian Coding. All rights reserved.

#ifndef BCTypes_h
#define BCTypes_h


#endif /* BCTypes_h */
