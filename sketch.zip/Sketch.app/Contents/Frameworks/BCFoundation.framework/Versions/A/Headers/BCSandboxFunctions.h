//
//  BCSandboxFunctions.h
//  BCFoundation
//
//  Created by Johnnie Walker on 16/10/2015.
//  Copyright © 2015 Bohemian Coding. All rights reserved.
//

/// returns YES if the app is running is a sandboxed environment
BOOL BCAppIsSandboxed(void);